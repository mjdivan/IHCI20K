SDAL (c) by Departamento de Computacion, FCEyN, UBA.

SDAL is licensed under a
Creative Commons Attribution-ShareAlike 3.0 Unported License.
See LICENSE.txt.


*****ESPAÑOL*****

Columnas de meanAndStdev.csv:

palabra
media_agrado
media_activacion
media_imaginabilidad
stdev_agrado
stdev_activacion
stdev_imaginabilidad

Los valores de las medias están en una escala de 1 a 3.
Visitá http://habla.dc.uba.ar/gravano/sdal.php para más información.

*****ENGLISH*****

Columns in meanAndStdev.csv:

word
pleasantness_mean
activation_mean
imagery_mean
pleasantness_stdev
activation_stdev
imagery_stdev

Mean values are in a 1-3 scale.
Visit http://habla.dc.uba.ar/gravano/sdal.php for more information.

